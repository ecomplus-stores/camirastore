# Widget Trustvox

Storefront plugin for Trustvox reviews widgets

```js
import widgetTrustvox from '@ecomplus/widget-trustvox'

widgetTrustvox({
  trustvoxStoreId: 123
})
```
